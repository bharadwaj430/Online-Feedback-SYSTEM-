# 🎓 College Feedback System
A full-stack web app built with Python (Flask) + SQLite.

## Quick Start

```bash
# 1. Install dependencies
pip install flask

# 2. Run the app
python app.py

# 3. Open in browser
http://127.0.0.1:5000
```

## Pages
| URL | Purpose |
|-----|---------|
| `/` | Student feedback form |
| `/success` | Confirmation page |
| `/admin/login` | Admin login |
| `/admin` | Dashboard with filters & stats |

## Admin Credentials
- **Username:** `admin`
- **Password:** `admin@123`

*(Change these in `app.py` before deploying)*

## Features
- ✅ Submit feedback with star ratings (overall / teaching / content)
- ✅ Anonymous submission option
- ✅ Admin dashboard with stats, filters, charts
- ✅ Delete individual responses
- ✅ SQLite database (zero setup)
- ✅ Session-based admin login

## Project Structure
```
feedback_system/
├── app.py                  ← Flask app + routes + DB
├── requirements.txt
├── feedback.db             ← auto-created on first run
└── templates/
    ├── base.html           ← shared layout
    ├── index.html          ← feedback form
    ├── success.html        ← thank-you page
    ├── admin_login.html    ← login page
    └── admin.html          ← admin dashboard
```

## Free Deployment
| Platform | Steps |
|----------|-------|
| **PythonAnywhere** | Upload zip → set WSGI to `app.py` |
| **Render.com** | Push to GitHub → connect repo |
| **Railway.app** | `railway up` from project folder |
