from flask import Flask, render_template, request, redirect, url_for, session, flash
import sqlite3
import os
from datetime import datetime
from functools import wraps

app = Flask(__name__)
app.secret_key = "college_feedback_secret_2024"

DB_PATH = "feedback.db"
ADMIN_USERNAME = "admin"
ADMIN_PASSWORD = "admin@123"

SUBJECTS = [
    "Mathematics", "Physics", "Chemistry",
    "Data Structures", "Python Programming", "DBMS",
    "Operating Systems", "Computer Networks",
    "Engineering Drawing", "Communication Skills"
]

DEPARTMENTS = ["CSE", "IT", "ECE", "EEE", "MECH", "CIVIL"]

# ─── DB SETUP ───────────────────────────────────────────────────────────────

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with get_db() as conn:
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS feedback (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                student_name TEXT,
                roll_number  TEXT,
                department   TEXT NOT NULL,
                year         TEXT NOT NULL,
                subject      TEXT NOT NULL,
                faculty_name TEXT NOT NULL,
                rating       INTEGER NOT NULL CHECK(rating BETWEEN 1 AND 5),
                teaching     INTEGER NOT NULL CHECK(teaching BETWEEN 1 AND 5),
                content      INTEGER NOT NULL CHECK(content BETWEEN 1 AND 5),
                comments     TEXT,
                is_anonymous INTEGER DEFAULT 0,
                timestamp    TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS admin_log (
                id        INTEGER PRIMARY KEY AUTOINCREMENT,
                action    TEXT,
                timestamp TEXT
            );
        """)

# ─── AUTH ────────────────────────────────────────────────────────────────────

def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get("admin_logged_in"):
            return redirect(url_for("admin_login"))
        return f(*args, **kwargs)
    return decorated

# ─── ROUTES ──────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html", subjects=SUBJECTS, departments=DEPARTMENTS)

@app.route("/submit", methods=["POST"])
def submit():
    is_anon = "anonymous" in request.form
    name     = "" if is_anon else request.form.get("student_name", "").strip()
    roll     = "" if is_anon else request.form.get("roll_number", "").strip()
    dept     = request.form.get("department", "").strip()
    year     = request.form.get("year", "").strip()
    subject  = request.form.get("subject", "").strip()
    faculty  = request.form.get("faculty_name", "").strip()
    rating   = int(request.form.get("rating", 0))
    teaching = int(request.form.get("teaching", 0))
    content  = int(request.form.get("content", 0))
    comments = request.form.get("comments", "").strip()
    ts       = datetime.now().strftime("%Y-%m-%d %H:%M")

    errors = []
    if not dept:   errors.append("Department is required.")
    if not year:   errors.append("Year is required.")
    if not subject: errors.append("Subject is required.")
    if not faculty: errors.append("Faculty name is required.")
    if not (1 <= rating <= 5):   errors.append("Overall rating is required.")
    if not (1 <= teaching <= 5): errors.append("Teaching quality rating is required.")
    if not (1 <= content <= 5):  errors.append("Content rating is required.")

    if errors:
        flash(errors, "error")
        return redirect(url_for("index"))

    with get_db() as conn:
        conn.execute("""
            INSERT INTO feedback
            (student_name, roll_number, department, year, subject, faculty_name,
             rating, teaching, content, comments, is_anonymous, timestamp)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (name, roll, dept, year, subject, faculty,
              rating, teaching, content, comments, int(is_anon), ts))

    return redirect(url_for("success"))

@app.route("/success")
def success():
    return render_template("success.html")

# ─── ADMIN ───────────────────────────────────────────────────────────────────

@app.route("/admin/login", methods=["GET", "POST"])
def admin_login():
    if request.method == "POST":
        u = request.form.get("username", "")
        p = request.form.get("password", "")
        if u == ADMIN_USERNAME and p == ADMIN_PASSWORD:
            session["admin_logged_in"] = True
            with get_db() as conn:
                conn.execute("INSERT INTO admin_log (action, timestamp) VALUES (?, ?)",
                             ("Login", datetime.now().strftime("%Y-%m-%d %H:%M")))
            return redirect(url_for("admin_dashboard"))
        flash("Invalid credentials.", "error")
    return render_template("admin_login.html")

@app.route("/admin/logout")
def admin_logout():
    session.clear()
    return redirect(url_for("index"))

@app.route("/admin")
@login_required
def admin_dashboard():
    dept_filter    = request.args.get("dept", "")
    subject_filter = request.args.get("subject", "")
    rating_filter  = request.args.get("rating", "")

    query  = "SELECT * FROM feedback WHERE 1=1"
    params = []

    if dept_filter:
        query += " AND department = ?"; params.append(dept_filter)
    if subject_filter:
        query += " AND subject = ?"; params.append(subject_filter)
    if rating_filter:
        query += " AND rating = ?"; params.append(int(rating_filter))

    query += " ORDER BY timestamp DESC"

    with get_db() as conn:
        rows = conn.execute(query, params).fetchall()
        total = conn.execute("SELECT COUNT(*) FROM feedback").fetchone()[0]
        avg_r = conn.execute("SELECT ROUND(AVG(rating),1) FROM feedback").fetchone()[0] or 0
        avg_t = conn.execute("SELECT ROUND(AVG(teaching),1) FROM feedback").fetchone()[0] or 0
        avg_c = conn.execute("SELECT ROUND(AVG(content),1) FROM feedback").fetchone()[0] or 0
        by_subject = conn.execute("""
            SELECT subject, ROUND(AVG(rating),1) as avg_r, COUNT(*) as cnt
            FROM feedback GROUP BY subject ORDER BY avg_r DESC
        """).fetchall()

    stats = dict(total=total, avg_r=avg_r, avg_t=avg_t, avg_c=avg_c)
    return render_template("admin.html",
        feedbacks=rows, stats=stats,
        subjects=SUBJECTS, departments=DEPARTMENTS,
        by_subject=by_subject,
        dept_filter=dept_filter,
        subject_filter=subject_filter,
        rating_filter=rating_filter
    )

@app.route("/admin/delete/<int:fid>", methods=["POST"])
@login_required
def delete_feedback(fid):
    with get_db() as conn:
        conn.execute("DELETE FROM feedback WHERE id = ?", (fid,))
    flash("Feedback deleted.", "success")
    return redirect(url_for("admin_dashboard"))

if __name__ == "__main__":
    init_db()
    print("✅  Feedback System running → http://127.0.0.1:5000")
    app.run(debug=True)
